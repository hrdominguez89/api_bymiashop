create view mia_view_orders_summary(date, cant, amount) as
SELECT date(mso.fecha_pedido) AS date,
       count(mso.id)          AS cant,
       sum(mso.total)         AS amount
FROM mia_shopping_order mso
GROUP BY (date(mso.fecha_pedido))
ORDER BY (date(mso.fecha_pedido)) DESC;

alter table mia_view_orders_summary
    owner to postgres;

